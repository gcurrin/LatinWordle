target_word = 'cedar'
guess = 'forts'

for tl, gl in zip(target_word, guess):
    print(tl, gl)