from app.main import app

# RUN THIS FILE TO RUN THE PROGRAM
# RUN THIS FILE TO RUN THE PROGRAM
# RUN THIS FILE TO RUN THE PROGRAM

if __name__ == "__main__":
    app.run(debug=True)